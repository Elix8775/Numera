# Numera

A fast scientific math library for Python, powered by Cython.

## Installation
pip install Numera

## Modules
- `Numera.Core.Matrices` — Linear algebra
- `Numera.Stats` — Descriptive statistics
- `Numera.Calculus` — Derivatives, integrals, ODE
- `Numera.Math` — Log, exp, factorial, combinations

## Quick start
from Numera.Core.Matrices import Matrix
from Numera.Stats import Stats
from Numera.Calculus import Calculus
from Numera.Math import Math

A = Matrix([[1, 2], [3, 4]])
print(A.det())   # -2.0